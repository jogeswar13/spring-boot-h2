package com.spaient.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.spaient.dao.ProductMasterDao;
import com.spaient.model.ProductMaster;

/**
 * 
 * @author jogeswarsahu
 *
 */
@Repository
public class ProductMasterDaoImpl implements ProductMasterDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public String createProducts(ProductMaster product) {
		entityManager.unwrap(Session.class).persist(product);
		entityManager.unwrap(Session.class).flush();
		return "success";
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<ProductMaster> searchProducts(String searchValue) {
		Criteria criteria = entityManager.unwrap(Session.class).createCriteria(ProductMaster.class)
				.add(Restrictions.ilike("productName", searchValue));
		return criteria.list();
	}

}
