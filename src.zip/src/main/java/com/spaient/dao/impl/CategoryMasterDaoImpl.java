package com.spaient.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.spaient.dao.CategoryMasterDao;
import com.spaient.model.CategoryMaster;

/**
 * 
 * @author jogeswar
 *
 */
@Repository
public class CategoryMasterDaoImpl implements CategoryMasterDao {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String createCategory(CategoryMaster category) {
		try {
			entityManager.unwrap(Session.class).persist(category);
			entityManager.unwrap(Session.class).flush();
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterDaoImpl at createCategory(): ", e);
		}
		return "success";
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CategoryMaster> getAllCategory() {

		List<CategoryMaster> categoryList = new ArrayList<>();

		try {
			Criteria criteria = entityManager.unwrap(Session.class).createCriteria(CategoryMaster.class);
			categoryList = criteria.list();
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterDaoImpl at getAllCategory(): ", e);
		}
		return categoryList;
	}

}
