package com.spaient.dao;

import java.util.List;

import com.spaient.model.CategoryMaster;

/**
 * 
 * @author jogeswar
 *
 */
public interface CategoryMasterDao {

	public String createCategory(CategoryMaster category);

	public List<CategoryMaster> getAllCategory();

}
