package com.spaient.dao;

import java.util.List;

import com.spaient.model.ProductMaster;

public interface ProductMasterDao {

	String createProducts(ProductMaster product);

	List<ProductMaster> searchProducts(String searchValue);

}
