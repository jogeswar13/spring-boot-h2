package com.spaient.service;

import java.util.List;

import com.spaient.model.ProductMaster;

public interface ProductMasterService {

	String createProducts(List<ProductMaster> productList);

	List<ProductMaster> searchProducts(String searchValue);

}
