package com.spaient.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spaient.dao.ProductMasterDao;
import com.spaient.model.ProductMaster;
import com.spaient.service.ProductMasterService;

@Service
public class ProductMasterServiceImpl implements ProductMasterService {

	@Autowired
	private ProductMasterDao userDao;

	@Override
	public String createProducts(List<ProductMaster> productList) {

		if ((null != productList) && (!productList.isEmpty())) {
			for (ProductMaster product : productList) {
				userDao.createProducts(product);
			}
		}

		return "success";
	}

	@Override
	public List<ProductMaster> searchProducts(String searchValue) {
		
		/*List<ProductBean> productBeanList = null;
		ProductBean productBean = null;
		List<ProductMaster> productList = null;
		productList = userDao.searchProducts(searchValue);
		
		if ((null != productList) && (!productList.isEmpty())) {
			for (ProductMaster product : productList) {
				productBean = new ProductBean();
			}
		}*/
		
		
		
		return userDao.searchProducts(searchValue);
	}

}
