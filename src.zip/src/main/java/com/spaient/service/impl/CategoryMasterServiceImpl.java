package com.spaient.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.spaient.bean.CategoryBean;
import com.spaient.dao.CategoryMasterDao;
import com.spaient.model.CategoryMaster;
import com.spaient.service.CategoryMasterService;

/**
 * 
 * @author joges
 *
 */
@Service
@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
public class CategoryMasterServiceImpl implements CategoryMasterService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CategoryMasterDao categoryMasterDao;

	@Override
	public String createCategory(List<CategoryBean> categoryBeanList) {

		String status = "failure";
		CategoryMaster category = null;

		try {
			if ((null != categoryBeanList) && (!categoryBeanList.isEmpty())) {
				for (CategoryBean categoryBean : categoryBeanList) {
					if (null != categoryBean) {
						category = new CategoryMaster();
						category.setCategoryName(categoryBean.getCategoryName());
						category.setCategoryDesc(categoryBean.getCategoryDesc());
						
						status = categoryMasterDao.createCategory(category);
					} else {
						status = "Empty Request!!";
					}
				}
			}
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterServiceImpl at createCategory(): ", e);
		}

		return status;
	}

	@Override
	public List<CategoryMaster> getAllCategory() {

		List<CategoryMaster> categoryList = new ArrayList<>();

		try {
			categoryList = categoryMasterDao.getAllCategory();
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterServiceImpl at getAllCategory(): ", e);
		}

		return categoryList;
	}

}
