package com.spaient.service;

import java.util.List;

import com.spaient.bean.CategoryBean;
import com.spaient.model.CategoryMaster;

/**
 * 
 * @author jogeswar
 *
 */
public interface CategoryMasterService {

	public String createCategory(List<CategoryBean> categoryBeanList);

	public List<CategoryMaster> getAllCategory();

}
