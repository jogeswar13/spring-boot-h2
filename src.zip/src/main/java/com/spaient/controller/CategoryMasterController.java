package com.spaient.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.spaient.bean.CategoryBean;
import com.spaient.model.CategoryMaster;
import com.spaient.service.CategoryMasterService;

/**
 * 
 * @author jogeswar
 *
 */
@RestController
@RequestMapping(value = "category-api")
public class CategoryMasterController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CategoryMasterService categoryMasterService;

	@PostMapping(value = "/createCategory", produces = { "application/json" })
	public ResponseEntity<String> createCategory(@RequestBody List<CategoryBean> categoryBeanList) {

		ResponseEntity<String> responseEntity = new ResponseEntity<>(null, HttpStatus.NO_CONTENT);

		try {
			responseEntity = ResponseEntity.ok(new Gson().toJson(categoryMasterService.createCategory(categoryBeanList)));
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterController at createCategory(): ", e);
		}

		return responseEntity;
	}

	@GetMapping(value = "/getAllCategory", produces = { "application/json" })
	public ResponseEntity<List<CategoryMaster>> getAllCategory() {

		ResponseEntity<List<CategoryMaster>> responseEntity = new ResponseEntity<>(null, HttpStatus.NO_CONTENT);

		try {
			responseEntity = ResponseEntity.ok(categoryMasterService.getAllCategory());
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterController at getAllCategory(): ", e);
		}

		return responseEntity;
	}

}
