package com.spaient.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.spaient.model.ProductMaster;
import com.spaient.service.ProductMasterService;

/**
 * 
 * @author jogeswar
 *
 */
@RestController
@RequestMapping(value = "product-api")
public class ProductMasterController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ProductMasterService productMasterService;

	@PostMapping(value = "/createProduct", produces = { "application/json" })
	public ResponseEntity<String> createProduct(@RequestBody List<ProductMaster> productList) {

		ResponseEntity<String> responseEntity = new ResponseEntity<>(null, HttpStatus.NO_CONTENT);

		try {
			responseEntity = ResponseEntity.ok(new Gson().toJson(productMasterService.createProducts(productList)));
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterController at createProduct(): ", e);
		}

		return responseEntity;
	}

	@GetMapping(value = "/searchProducts", produces = { "application/json" })
	public ResponseEntity<List<ProductMaster>> searchProducts(@RequestParam("searchValue") String searchValue) {

		ResponseEntity<List<ProductMaster>> responseEntity = new ResponseEntity<>(null, HttpStatus.NO_CONTENT);

		try {
			responseEntity = ResponseEntity.ok(productMasterService.searchProducts(searchValue));
		} catch (Exception e) {
			logger.error("@@@ Exception in CategoryMasterController at searchProducts(): ", e);
		}

		return responseEntity;
	}

}
