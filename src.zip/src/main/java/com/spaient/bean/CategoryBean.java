package com.spaient.bean;

/**
 * 
 * @author jogeswarsahu
 *
 */
public class CategoryBean {

	private Long catNo;
	private String categoryName;
	private String categoryDesc;

	public Long getCatNo() {
		return catNo;
	}

	public void setCatNo(Long catNo) {
		this.catNo = catNo;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

}
