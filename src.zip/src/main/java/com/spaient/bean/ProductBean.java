package com.spaient.bean;

/**
 * 
 * @author jogeswarsahu
 *
 */
public class ProductBean {

	private Long catNo;
	private String categoryName;
	private String categoryDesc;

	private String productId;
	private String productName;
	private String productDesc;
	private String productImgUrl;

	public Long getCatNo() {
		return catNo;
	}

	public void setCatNo(Long catNo) {
		this.catNo = catNo;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductImgUrl() {
		return productImgUrl;
	}

	public void setProductImgUrl(String productImgUrl) {
		this.productImgUrl = productImgUrl;
	}

}
